function cambiarFondo() {
    document.body.style.backgroundColor = 'pink';
    document.getElementById('cambiarColor').textContent = 'tiamo :>';
}